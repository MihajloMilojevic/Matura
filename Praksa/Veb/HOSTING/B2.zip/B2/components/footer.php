<!DOCTYPE html>
<html lang="sr-RS">
<body>
	<footer>
		Copyrigth &copy Predškolska ustanova "Srećno dete"
	</footer>
</body>
</html>